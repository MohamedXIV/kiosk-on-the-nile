Kiosk on the Nile — social visitors + compact HUD preview
Source: c752382f9ed0a3a1f7115cdb309db223c592b650

Extract the entire ZIP, including content/.
Do not open index.html with file://.

In PowerShell, inside this folder:
  py -m http.server 8765 --bind 127.0.0.1
Then open: http://127.0.0.1:8765/

Controls: WASD/arrows, E primary, F secondary, N notebook.
Save and help are in the top menu.

Tuning: content/visitors.json, content/encounters.json, content/ui.json.
Dialogue: authored compiled Ink in content/stories/.
Keep the original source Ink and compiled JSON synchronized when editing dialogue.

This preview includes four additional named visitors, visit quotas/time windows,
persistent consumed dialogue topics, real paid-service memories and a compact HUD.
Arabic UI/dialogue. Full multi-day pacing review remains open.
